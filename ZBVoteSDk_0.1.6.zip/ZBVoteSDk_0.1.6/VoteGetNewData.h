//
//  VoteGetNewData.h
//  ZhiBoApplication
//
//  Created by 崔波 on 16/8/24.
//  Copyright © 2016年 ZhiBo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AnchorVotingView.h"
@interface VoteGetNewData : NSObject
/**
 *  进入直播间获取最新投票信息
 *
 *  @param voteID     当前直播间主播usid
 *  @param completion 获取结果的回调，如果正常的话返回data数据
 */
- (void)getNewVoteDataWithVoteID:(NSString *)voteID
                      completion:(void(^)(id data))completion
                           error:(void(^)(NSError *error))error;

- (void)getVotingDataWithVoteID:(NSString *)voteID
                     completion:(void(^)(id data))completion
                          error:(void(^)(NSError *error))error;

- (void)getVoteGiftDataWithVoteID:(NSString *)vote_id
                       option_key:(NSString *)chooseOption
                            count:(NSInteger)count
                       completion:(void(^)(id data))completion
                            error:(void(^)(NSError *error))error;
@end
