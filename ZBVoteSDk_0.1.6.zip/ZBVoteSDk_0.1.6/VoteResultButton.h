//
//  VoteResultButton.h
//  ZhiBoApplication
//
//  Created by 崔波 on 16/8/24.
//  Copyright © 2016年 ZhiBo. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface VoteResultButton : UIButton

@end
