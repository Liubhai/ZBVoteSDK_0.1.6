//
//  AnchorApplyView.h
//  ZhiBoApplication
//
//  Created by 崔波 on 16/8/20.
//  Copyright © 2016年 ZhiBo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ZBCloudData.h>
#import "voteHeader.h"
@protocol AnchorApplyViewDelegate <NSObject>
- (void)createvoteView :(NSMutableArray *)arr :(BOOL)flag :(NSString *)time :(NSString *)voteid;

@end

@interface AnchorApplyView : UIView<UITextFieldDelegate>

@property (nonatomic, assign) id<AnchorApplyViewDelegate> delegate;
@property (nonatomic, strong) UIView *BGView;//主播发起投票弹框视图
@property (nonatomic, strong) UITextField *textfieldA;//选项A
@property (nonatomic, strong) UITextField *textfieldB;//选项B
@property (nonatomic, strong) UITextField *textfieldC;//选项C
@property (nonatomic, strong) UITextField *textfieldD;//选项D
@property (nonatomic, strong) UIButton *voteSignButton;//发起投票按钮
@property (nonatomic, strong) UIButton *buttonAdd;//添加选项按钮
@property (nonatomic, strong) UIButton *cancelButton;//取消投票按钮
@property (nonatomic, strong) NSMutableArray *timeButtonArr;//用于存放具体时长按钮的数组
@property (nonatomic, strong) NSMutableArray *optionsArr;//投票选项内容
@property (nonatomic, strong) NSMutableArray *dataArr;//发起投票之后请求接口所得投票信息数据
@property (nonatomic, strong) UIButton *buttonA;
@property (nonatomic, strong) UIButton *buttonB;
@property (nonatomic, strong) UIButton *buttonC;
@property (nonatomic, strong) UIButton *buttonD;

@property (nonatomic, assign) int chooseCount;
@property (nonatomic, assign) CGFloat height;//刚弹起发起投票界面时候的高度
@property (nonatomic, assign) CGFloat jianju;//选项边距
@property (nonatomic, assign) CGFloat BGViewCurrentHeight;//投票界面当前高度
@property (nonatomic, assign) CGFloat KeyboardH;//键盘高度
@property (nonatomic, strong) NSString *timeStr;//当前选择的时长
@property (nonatomic, assign) int voteCount;//发起投票的次数
@property (nonatomic, strong) NSString *vote_id;//投票id
@property (nonatomic, strong) NSString *optionstr;//传参数用到的选项参数
@property (nonatomic, assign) BOOL flag;//
@end
