//
//  VoteChooseView.h
//  ZhiBoApplication
//
//  Created by 崔波 on 16/8/25.
//  Copyright © 2016年 ZhiBo. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol VoteChooseViewDelegate<NSObject>
- (void)chooseGift:(NSString *)option;//选择的投票对象
@end
@interface VoteChooseView : UIView
@property (nonatomic, assign)id<VoteChooseViewDelegate> delegate;
- (void)createChooseVoteView:(NSMutableArray *)chooseArr;
@end
