//
//  AnchorvoteResultView.h
//  ZhiBoApplication
//
//  Created by 崔波 on 16/8/20.
//  Copyright © 2016年 ZhiBo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VoteView.h"
@protocol AnchorvoteResultViewDelegate<NSObject>
- (void)shouqiView:(CGRect)frames;
@end
@interface AnchorvoteResultView : UIView<VoteViewDelegate>
@property (nonatomic, assign) id<AnchorvoteResultViewDelegate> delegate;
@property (nonatomic, strong) VoteView *voteViewA;
@property (nonatomic, strong) VoteView *voteViewB;
@property (nonatomic, strong) VoteView *voteViewC;
@property (nonatomic, strong) VoteView *voteViewD;
@property (nonatomic, assign) CGRect resultViewframe;
@property (nonatomic, assign) CGFloat with;//投票选项里面的最大的宽度
- (NSMutableArray *)getdataArr:(NSMutableArray *)arr;
- (void)createVoteResultView :(NSMutableArray *)arr :(CGFloat)y :(CGFloat)height;
@end
