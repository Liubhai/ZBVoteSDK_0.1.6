//
//  AnchorVotingView.h
//  ZhiBoApplication
//
//  Created by 崔波 on 16/8/20.
//  Copyright © 2016年 ZhiBo. All rights reserved.
//

#import <UIKit/UIKit.h>
#include "VoteView.h"
@protocol AnchorVotingViewDelegate<NSObject>
- (void)createVoteResult:(NSMutableArray *)voteViewArr :(CGFloat)h;//创建投票结果视图
- (void)showVoteChooseView:(NSMutableArray *)chooseArr;//观众界面弹起投票视图
@end
@interface AnchorVotingView : UIView<VoteViewDelegate>
@property (nonatomic, assign) id<AnchorVotingViewDelegate> delegate;
@property (nonatomic, strong) NSMutableArray *voteResultArr;//投票结果视图
@property (nonatomic, strong) UILabel *timeLabel;//倒计时
@property (nonatomic, strong) UILabel *label;//“倒计时”
@property (nonatomic, strong) VoteView *voteViewA;
@property (nonatomic, strong) VoteView *voteViewB;
@property (nonatomic, strong) VoteView *voteViewC;
@property (nonatomic, strong) VoteView *voteViewD;
@property (nonatomic, strong) NSString *timeStr;//当前选择的时长
@property (nonatomic, assign) BOOL flag;
- (void)createVotingView:(NSMutableArray *)arr :(BOOL)isflag :(NSString *)timestr :(CGFloat)y;
- (void)setValue:(NSMutableArray *)arr;
@end
