//
//  VoteView.h
//  Pods
//
//  Created by 崔波 on 16/8/12.
//
//

#import <UIKit/UIKit.h>
#import "voteHeader.h"
@protocol VoteViewDelegate <NSObject>

- (void)GetWith:(CGFloat)with;
- (void)showVoteView;

@end

@interface VoteView : UIView
@property (nonatomic, assign) id<VoteViewDelegate> delegate;
@property (nonatomic, strong) UIView *bgView;//进度背景视图
@property (nonatomic, strong) UILabel *progressLabel;//显示进度
@property (nonatomic, strong) UIButton *titleButton;//选项内容
@property (nonatomic, strong) UIImageView *imageView;//金币
@property (nonatomic, strong) UILabel *countLabel;//金币数量

@property (nonatomic, strong) NSString *titleStr;//选项内容
@property (nonatomic, assign) NSInteger countNum;//金币数量值
@end
